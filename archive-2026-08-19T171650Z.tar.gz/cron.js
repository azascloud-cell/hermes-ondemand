const cron = require("node-cron");
const config = require("./config");

/**
 * Daftarkan semua cronjob di sini.
 * @param {import("grammy").Bot} bot
 */
function setupCronJobs(bot) {
  // Contoh: kirim pesan terjadwal ke chat tertentu (isi CRON_TARGET_CHAT_ID di .env kalau mau pakai ini)
  cron.schedule(
    config.cronSchedule,
    async () => {
      const targetChatId = process.env.CRON_TARGET_CHAT_ID;
      if (!targetChatId) {
        console.log("[cron] CRON_TARGET_CHAT_ID belum di-set, skip pengiriman.");
        return;
      }
      try {
        await bot.api.sendMessage(
          targetChatId,
          "⏰ Ini pesan terjadwal otomatis dari bot kamu!"
        );
        console.log("[cron] Pesan terjadwal terkirim.");
      } catch (err) {
        console.error("[cron] Gagal mengirim pesan terjadwal:", err);
      }
    },
    { timezone: config.cronTimezone }
  );

  console.log(
    `[cron] Cronjob aktif dengan jadwal "${config.cronSchedule}" (timezone ${config.cronTimezone})`
  );

  // Tambahkan cron.schedule(...) lain di sini untuk tugas berkala tambahan,
  // misalnya membersihkan memory lama, mengirim ringkasan mingguan, dll.
}

module.exports = { setupCronJobs };
