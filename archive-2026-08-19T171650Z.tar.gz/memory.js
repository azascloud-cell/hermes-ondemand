const db = require("./db");
const config = require("./config");

// --- Topic management ---

const insertTopic = db.prepare(
  "INSERT INTO topics (chat_id, name, is_active, created_at) VALUES (?, ?, 1, ?)"
);
const deactivateAllTopics = db.prepare(
  "UPDATE topics SET is_active = 0 WHERE chat_id = ?"
);
const activateTopic = db.prepare(
  "UPDATE topics SET is_active = 1 WHERE id = ?"
);
const getActiveTopicStmt = db.prepare(
  "SELECT id, name FROM topics WHERE chat_id = ? AND is_active = 1 LIMIT 1"
);
const getTopicByName = db.prepare(
  "SELECT id, name FROM topics WHERE chat_id = ? AND name = ? LIMIT 1"
);
const listTopicsStmt = db.prepare(
  "SELECT id, name, is_active FROM topics WHERE chat_id = ? ORDER BY created_at ASC"
);

/**
 * Ambil topic yang sedang aktif untuk chat ini. Kalau belum ada topic sama sekali
 * (chat baru pertama kali chat), otomatis buat topic default "general".
 */
function getActiveTopic(chatId) {
  const existing = getActiveTopicStmt.get(String(chatId));
  if (existing) return existing;

  const result = insertTopic.run(String(chatId), "general", Date.now());
  return { id: result.lastInsertRowid, name: "general" };
}

/**
 * Buat topic baru dan langsung jadikan aktif.
 * Kalau nama topic sudah ada, langsung switch ke topic itu (tidak duplikat).
 */
function createTopic(chatId, name) {
  const existing = getTopicByName.get(String(chatId), name);
  deactivateAllTopics.run(String(chatId));

  if (existing) {
    activateTopic.run(existing.id);
    return { id: existing.id, name: existing.name, reused: true };
  }

  const result = insertTopic.run(String(chatId), name, Date.now());
  return { id: result.lastInsertRowid, name, reused: false };
}

/**
 * Pindah ke topic yang sudah ada berdasarkan nama.
 * Return null kalau topic dengan nama itu tidak ditemukan.
 */
function switchTopic(chatId, name) {
  const existing = getTopicByName.get(String(chatId), name);
  if (!existing) return null;

  deactivateAllTopics.run(String(chatId));
  activateTopic.run(existing.id);
  return existing;
}

function listTopics(chatId) {
  return listTopicsStmt.all(String(chatId));
}

// --- Message history (di-scope per topic) ---

const insertMessage = db.prepare(
  "INSERT INTO messages (topic_id, role, content, created_at) VALUES (?, ?, ?, ?)"
);
const getRecentMessages = db.prepare(
  `SELECT role, content FROM messages
   WHERE topic_id = ?
   ORDER BY created_at DESC
   LIMIT ?`
);
const deleteOldMessages = db.prepare(
  `DELETE FROM messages WHERE topic_id = ? AND id NOT IN (
     SELECT id FROM messages WHERE topic_id = ? ORDER BY created_at DESC LIMIT ?
   )`
);
const clearMessagesByTopic = db.prepare("DELETE FROM messages WHERE topic_id = ?");

function addMessage(topicId, role, content) {
  insertMessage.run(topicId, role, content, Date.now());
  deleteOldMessages.run(topicId, topicId, config.memoryWindow);
}

function getHistory(topicId) {
  const rows = getRecentMessages.all(topicId, config.memoryWindow);
  return rows.reverse(); // urut dari lama ke baru
}

function clearTopicHistory(topicId) {
  clearMessagesByTopic.run(topicId);
}

// --- Facts (global per chat, lintas topic) ---

const insertFact = db.prepare(
  "INSERT INTO facts (chat_id, fact, created_at) VALUES (?, ?, ?)"
);
const getFacts = db.prepare(
  "SELECT fact FROM facts WHERE chat_id = ? ORDER BY created_at ASC"
);
const clearFacts = db.prepare("DELETE FROM facts WHERE chat_id = ?");

function addFact(chatId, fact) {
  insertFact.run(String(chatId), fact, Date.now());
}

function getAllFacts(chatId) {
  return getFacts.all(String(chatId)).map((r) => r.fact);
}

/**
 * Reset total: hapus semua topic, history, dan fakta milik chat ini.
 */
function resetAll(chatId) {
  const topics = listTopics(chatId);
  for (const t of topics) {
    clearMessagesByTopic.run(t.id);
  }
  db.prepare("DELETE FROM topics WHERE chat_id = ?").run(String(chatId));
  clearFacts.run(String(chatId));
}

module.exports = {
  getActiveTopic,
  createTopic,
  switchTopic,
  listTopics,
  addMessage,
  getHistory,
  clearTopicHistory,
  addFact,
  getAllFacts,
  resetAll,
};
