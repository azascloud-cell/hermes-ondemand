const path = require("path");
const Database = require("better-sqlite3");

const dbPath = path.join(__dirname, "db", "bot.sqlite");
const db = new Database(dbPath);

db.pragma("journal_mode = WAL");

// Topic = sesi percakapan terpisah dalam satu chat. Satu topic aktif per chat.
db.exec(`
  CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id TEXT NOT NULL,
    name TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_topics_chat ON topics(chat_id);
`);

// Riwayat percakapan (memory jangka pendek), sekarang di-scope per topic
db.exec(`
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id INTEGER NOT NULL,
    role TEXT NOT NULL,       -- 'user' or 'assistant'
    content TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_messages_topic ON messages(topic_id, created_at);
`);

// Catatan fakta jangka panjang tentang user (global per chat, dipakai di semua topic)
db.exec(`
  CREATE TABLE IF NOT EXISTS facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id TEXT NOT NULL,
    fact TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_facts_chat ON facts(chat_id);
`);

module.exports = db;
