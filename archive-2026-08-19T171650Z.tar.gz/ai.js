const config = require("./config");

/**
 * Panggil OpenCode Zen (endpoint OpenAI-compatible) untuk mendapatkan balasan AI.
 * @param {Array<{role: string, content: string}>} messages
 * @returns {Promise<string>}
 */
async function askAI(messages) {
  const res = await fetch(`${config.opencodeBaseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${config.opencodeApiKey}`,
    },
    body: JSON.stringify({
      model: config.opencodeModel,
      messages,
      max_tokens: 1000,
    }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`OpenCode Zen error ${res.status}: ${errText}`);
  }

  const data = await res.json();
  const reply = data?.choices?.[0]?.message?.content;

  if (!reply) {
    throw new Error("OpenCode Zen returned an empty response");
  }

  return reply.trim();
}

/**
 * Bangun array messages untuk dikirim ke AI: system prompt + fakta jangka panjang
 * + riwayat percakapan (memory pendek) + pesan baru.
 */
function buildPrompt({ systemPrompt, facts, history, userMessage }) {
  const messages = [];

  let system = systemPrompt;
  if (facts && facts.length > 0) {
    system += `\n\nHal-hal yang kamu ingat tentang user ini:\n- ${facts.join("\n- ")}`;
  }
  messages.push({ role: "system", content: system });

  for (const h of history) {
    messages.push({ role: h.role, content: h.content });
  }

  messages.push({ role: "user", content: userMessage });

  return messages;
}

module.exports = { askAI, buildPrompt };
