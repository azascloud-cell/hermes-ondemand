# Telegram AI Agent Bot (OpenCode Zen + SQLite Memory + Cronjob)

Bot Telegram AI dengan:
- **Backend AI**: [OpenCode Zen](https://opencode.ai/zen) (endpoint OpenAI-compatible, model gratis)
- **Memory**: SQLite (`better-sqlite3`) — riwayat chat pendek per user + fakta jangka panjang
- **Cronjob**: `node-cron` untuk tugas terjadwal
- **Bot framework**: [grammy](https://grammy.dev)

## 1. Siapkan kredensial

1. Buat bot Telegram lewat [@BotFather](https://t.me/BotFather) → dapat `TELEGRAM_BOT_TOKEN`
2. Daftar di https://opencode.ai/zen → dapat `OPENCODE_API_KEY` (gratis, tidak perlu kartu kredit)
3. Salin `.env.example` jadi `.env`, isi kedua token tadi

## 2. Jalankan lokal (opsional, buat testing)

```bash
npm install
cp .env.example .env
# edit .env, isi token
npm start
```

## 3. Deploy ke Pterodactyl

### a. Buat server baru
- Pilih **Egg: Node.js** (versi Node 18+ direkomendasikan, project ini pakai `fetch` bawaan Node 18)
- Startup command biasanya: `node {{MAIN_FILE}}` — set `MAIN_FILE` = `index.js`

### b. Upload project
- Upload semua file ini ke folder server (lewat file manager panel atau SFTP)
- Atau push ke git repo lalu clone dari panel kalau eggnya support

### c. Set environment variables
Di tab **Startup** Pterodactyl, isi variable berikut (sesuaikan nama field sesuai egg yang dipakai):
- `TELEGRAM_BOT_TOKEN`
- `OPENCODE_API_KEY`
- `OPENCODE_MODEL` (default: `big-pickle`)
- `OPENCODE_BASE_URL` (default: `https://opencode.ai/zen/v1`)
- `CRON_SCHEDULE`, `CRON_TIMEZONE`, `CRON_TARGET_CHAT_ID` (opsional, buat cronjob)

Kalau egg-nya tidak expose env var custom, cukup upload file `.env` langsung ke root folder project — `dotenv` akan otomatis membacanya.

### d. Install dependencies
Buka **Console** di panel, jalankan:
```bash
npm install
```
> Catatan: `better-sqlite3` perlu kompilasi native module. Kebanyakan image Node.js Pterodactyl sudah menyertakan `build-essential`/`python3`. Kalau `npm install` gagal karena ini, ganti egg ke image yang menyertakan compiler, atau ganti library ke `node:sqlite` bawaan Node 22+.

### e. Start server
Klik **Start** di panel. Bot akan langsung polling pesan Telegram.

## 4. Cara pakai bot

**Topic (sesi percakapan terpisah):**
- Chat biasa → otomatis masuk ke topic aktif (default: `general`), ingat 20 pesan terakhir di topic itu (atur lewat `MEMORY_WINDOW`)
- `/newtopic <nama>` → mulai sesi baru yang terpisah dari obrolan sebelumnya (mis. `/newtopic kerja`, `/newtopic curhat`)
- `/topics` → lihat semua topic yang pernah dibuat + tanda topic yang sedang aktif
- `/switch <nama>` → pindah balik ke topic lama, lanjutkan dari histori sebelumnya
- `/resettopic` → kosongkan history topic yang sedang aktif saja (topic lain tidak kena)

**Memory (fakta, berlaku lintas semua topic):**
- `/remember <teks>` → simpan fakta permanen (mis. nama, preferensi user)
- `/facts` → lihat semua fakta yang diingat
- `/forget` → hapus SEMUA memory (semua topic + history + fakta)

## 5. Menambah cronjob baru

Edit `cron.js`, tambahkan blok baru:
```js
cron.schedule("*/30 * * * *", () => {
  // tugas yang jalan tiap 30 menit
}, { timezone: config.cronTimezone });
```

## 6. Struktur file

```
telegram-ai-bot/
├── index.js       # entry point: handler pesan + start bot
├── config.js      # baca environment variables
├── ai.js          # koneksi ke OpenCode Zen
├── memory.js       # baca/tulis memory dari SQLite
├── db.js          # koneksi & skema SQLite
├── cron.js        # daftar cronjob
├── db/bot.sqlite  # file database (dibuat otomatis saat pertama jalan)
├── .env.example
└── package.json
```

## Catatan tentang memory "ala Hermes"

Implementasi ini pakai 2 lapis memory:
1. **Short-term**: riwayat N pesan terakhir per chat, otomatis di-trim
2. **Long-term**: fakta eksplisit yang disimpan via `/remember`, selalu disisipkan ke system prompt

Kalau butuh long-term memory yang lebih pintar (retrieval semantik berbasis embedding, bukan cuma daftar fakta manual), langkah lanjutannya adalah menambah kolom vector/embedding di tabel `facts` dan pakai similarity search (misal dengan `sqlite-vec` atau `hnswlib-node`) sebelum menyisipkannya ke prompt.
