require("dotenv").config();

function required(name) {
  const val = process.env[name];
  if (!val) {
    console.error(`[config] Missing required env var: ${name}`);
    process.exit(1);
  }
  return val;
}

module.exports = {
  telegramToken: required("TELEGRAM_BOT_TOKEN"),
  opencodeApiKey: required("OPENCODE_API_KEY"),
  opencodeModel: process.env.OPENCODE_MODEL || "big-pickle",
  opencodeBaseUrl: process.env.OPENCODE_BASE_URL || "https://opencode.ai/zen/v1",
  systemPrompt:
    process.env.SYSTEM_PROMPT ||
    "Kamu adalah asisten AI yang ramah, singkat, dan membantu di Telegram.",
  memoryWindow: parseInt(process.env.MEMORY_WINDOW || "20", 10),
  cronSchedule: process.env.CRON_SCHEDULE || "0 7 * * *",
  cronTimezone: process.env.CRON_TIMEZONE || "Asia/Jakarta",
};
