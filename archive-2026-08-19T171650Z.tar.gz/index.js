const { Bot } = require("grammy");
const config = require("./config");
const memory = require("./memory");
const { askAI, buildPrompt } = require("./ai");
const { setupCronJobs } = require("./cron");

const bot = new Bot(config.telegramToken);

// --- Perintah dasar ---

bot.command("start", (ctx) =>
  ctx.reply(
    "Halo! Aku asisten AI kamu, ditenagai OpenCode Zen 🤖\n\n" +
      "Perintah topic (sesi percakapan):\n" +
      "/newtopic <nama> - mulai topic baru (obrolan lama tidak ikut kebawa)\n" +
      "/topics - lihat semua topic dan yang sedang aktif\n" +
      "/switch <nama> - pindah/lanjutkan ke topic yang sudah ada\n" +
      "/resettopic - hapus history topic yang sedang aktif\n\n" +
      "Perintah memory (fakta, berlaku lintas topic):\n" +
      "/remember <teks> - simpan fakta biar aku selalu ingat\n" +
      "/facts - lihat semua fakta yang aku ingat tentang kamu\n" +
      "/forget - hapus SEMUA memory (semua topic + fakta)\n\n" +
      "Selain itu, langsung chat aja seperti biasa!"
  )
);

bot.command("newtopic", (ctx) => {
  const name = ctx.match?.trim();
  if (!name) {
    return ctx.reply("Format: /newtopic <nama topic>\nContoh: /newtopic riset-skripsi");
  }
  const topic = memory.createTopic(ctx.chat.id, name);
  if (topic.reused) {
    return ctx.reply(`Topic "${topic.name}" sudah ada, langsung aku aktifkan.`);
  }
  return ctx.reply(`Topic baru "${topic.name}" dibuat dan aktif. Obrolan sebelumnya tersimpan aman di topic lain.`);
});

bot.command("topics", (ctx) => {
  const topics = memory.listTopics(ctx.chat.id);
  if (topics.length === 0) {
    return ctx.reply("Belum ada topic. Ngobrol aja dulu, nanti otomatis dibuatkan topic \"general\".");
  }
  const lines = topics.map((t) => `${t.is_active ? "➡️" : "  "} ${t.name}`);
  return ctx.reply("Daftar topic kamu:\n" + lines.join("\n"));
});

bot.command("switch", (ctx) => {
  const name = ctx.match?.trim();
  if (!name) {
    return ctx.reply("Format: /switch <nama topic>\nLihat daftar topic dengan /topics");
  }
  const topic = memory.switchTopic(ctx.chat.id, name);
  if (!topic) {
    return ctx.reply(`Topic "${name}" tidak ditemukan. Cek /topics atau buat baru dengan /newtopic ${name}`);
  }
  return ctx.reply(`Pindah ke topic "${topic.name}". Lanjut dari mana kamu berhenti terakhir kali.`);
});

bot.command("resettopic", (ctx) => {
  const topic = memory.getActiveTopic(ctx.chat.id);
  memory.clearTopicHistory(topic.id);
  return ctx.reply(`History topic "${topic.name}" sudah dikosongkan.`);
});

bot.command("remember", (ctx) => {
  const fact = ctx.match?.trim();
  if (!fact) {
    return ctx.reply("Format: /remember <hal yang mau diingat>\nContoh: /remember Nama saya Budi");
  }
  memory.addFact(ctx.chat.id, fact);
  return ctx.reply(`Oke, aku akan ingat: "${fact}"`);
});

bot.command("facts", (ctx) => {
  const facts = memory.getAllFacts(ctx.chat.id);
  if (facts.length === 0) {
    return ctx.reply("Belum ada fakta yang aku ingat tentang kamu.");
  }
  return ctx.reply("Yang aku ingat:\n- " + facts.join("\n- "));
});

bot.command("forget", (ctx) => {
  memory.resetAll(ctx.chat.id);
  return ctx.reply("Oke, semua topic, history, dan fakta kamu sudah aku hapus total.");
});

// --- Chat biasa ---

bot.on("message:text", async (ctx) => {
  const chatId = ctx.chat.id;
  const userMessage = ctx.message.text;

  await ctx.replyWithChatAction("typing");

  try {
    const topic = memory.getActiveTopic(chatId);
    const history = memory.getHistory(topic.id);
    const facts = memory.getAllFacts(chatId);

    const messages = buildPrompt({
      systemPrompt: config.systemPrompt,
      facts,
      history,
      userMessage,
    });

    const reply = await askAI(messages);

    memory.addMessage(topic.id, "user", userMessage);
    memory.addMessage(topic.id, "assistant", reply);

    await ctx.reply(reply);
  } catch (err) {
    console.error("[bot] Error handling message:", err);
    await ctx.reply("Maaf, terjadi kesalahan saat memproses pesanmu. Coba lagi ya.");
  }
});

// --- Error handling global ---

bot.catch((err) => {
  console.error("[bot] Unhandled error:", err);
});

// --- Cronjob ---

setupCronJobs(bot);

// --- Start bot ---

bot.start({
  onStart: () => console.log("[bot] Bot berhasil jalan dan siap menerima pesan."),
});
